# Middle East Analysis — iPad Trial Guide

This package is prepared for a browser/cloud development environment such as Replit.

## iPad setup
1. Open Replit in Safari and create a Node.js app.
2. Upload this ZIP and extract/import the project files.
3. Open the Shell/Console.
4. Run `npm install`.
5. Create environment variables/secrets:
   - `SESSION_SECRET` = a long random value
   - `ADMIN_EMAIL` = your admin email
   - `ADMIN_PASSWORD` = your admin password
   - `PORT` = `3000` (usually Replit assigns the port automatically; the app also respects Replit's PORT variable)
6. Run `npm start`.
7. Open the generated Preview/Webview URL.

## Test pages
- `/loading.html` — loading screen
- `/` — homepage
- `/submission.html` — submit an article
- `/admin` — editorial dashboard
- `/editorial-team.html` — editorial team

## Admin
Use the email/password stored in the environment variables. Do not put real production credentials in public source code.

## Important
This is a trial/development build. Before public launch, use HTTPS, a production database, secure cookies, a production session store, backups, rate limiting, CSRF protection, email notifications, and stronger access controls.
