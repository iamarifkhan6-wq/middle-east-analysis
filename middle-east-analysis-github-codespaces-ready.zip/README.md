# Middle East Analysis — Full Website

## Included
- Responsive public website
- Loading screen
- Homepage
- Analysis / Commentary / Research / Student / Countries / Themes / Experts sections
- Editorial Team page with four blank photo placeholders
- Article submission form
- Image upload for submissions
- SQLite database
- Editorial admin login
- Pending / approved / rejected workflow
- Admin article editing
- Published article pages
- Responsive mobile navigation

## Run locally

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Change the admin password and session secret.
4. Run:
   npm install
   npm start
5. Open:
   http://localhost:3000/loading.html
6. Editorial dashboard:
   http://localhost:3000/admin

The default admin credentials come from `.env`.

## Production notes
Use HTTPS, a strong SESSION_SECRET, a real production database/managed SQLite/PostgreSQL, secure cookies, email notifications, backups, rate limiting, CSRF protection and a proper production session store before public launch.
