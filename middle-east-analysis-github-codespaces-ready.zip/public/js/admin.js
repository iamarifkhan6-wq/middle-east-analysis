const loginBox=document.getElementById("loginBox"),dashboard=document.getElementById("dashboard"),list=document.getElementById("adminList"),panel=document.getElementById("editorPanel");
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
async function api(url,opt={}){const r=await fetch(url,{headers:{"Content-Type":"application/json",...(opt.headers||{})},...opt});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||"Request failed");return d}
async function check(){try{await api("/api/admin/me");showDash()}catch{}}
function showDash(){loginBox.hidden=true;dashboard.hidden=false;loadSubmissions()}
async function loadSubmissions(){
 const data=await api("/api/admin/submissions");
 list.innerHTML=data.length?data.map(a=>`<div class="submission-row"><div><span class="status ${a.status}">${a.status}</span><h3>${esc(a.title)}</h3><p>${esc(a.author_name)} · ${esc(a.email)} · ${esc(a.category)} · ${new Date(a.created_at).toLocaleString()}</p></div><div><button class="btn small" onclick="editSubmission(${a.id})">Review</button><button class="btn danger small" onclick="deleteSubmission(${a.id})">Delete</button></div></div>`).join(""):"<p class='muted'>No submissions.</p>";
}
async function editSubmission(id){
 const a=await api("/api/admin/submissions/"+id);
 panel.hidden=false;panel.innerHTML=`<h2>Review submission</h2><form id="editForm"><label>Title<input name="title" value="${esc(a.title)}"></label><label>Category<select name="category">${["Analysis","Commentary","Research Article","Student Perspective"].map(x=>`<option ${x===a.category?"selected":""}>${x}</option>`).join("")}</select></label><label>Abstract<textarea name="abstract" rows="5">${esc(a.abstract||"")}</textarea></label><label>Article<textarea name="body" rows="16">${esc(a.body)}</textarea></label><label>Author Bio<textarea name="bio" rows="4">${esc(a.bio||"")}</textarea></label><label>Status<select name="status"><option ${a.status==="pending"?"selected":""}>pending</option><option ${a.status==="approved"?"selected":""}>approved</option><option ${a.status==="rejected"?"selected":""}>rejected</option></select></label><label>Editor Note<textarea name="editorNote" rows="4">${esc(a.editor_note||"")}</textarea></label><button class="btn">Save Review</button></form>`;
 document.getElementById("editForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.target);const body=Object.fromEntries(f.entries());await api("/api/admin/submissions/"+id,{method:"PATCH",body:JSON.stringify(body)});panel.hidden=true;loadSubmissions()})
 panel.scrollIntoView({behavior:"smooth"});
}
async function deleteSubmission(id){if(!confirm("Delete this submission?"))return;await api("/api/admin/submissions/"+id,{method:"DELETE"});loadSubmissions()}
document.getElementById("loginForm")?.addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.target);try{await api("/api/admin/login",{method:"POST",body:JSON.stringify(Object.fromEntries(f.entries()))});showDash()}catch(x){document.getElementById("loginMsg").textContent=x.message}});
document.getElementById("logout")?.addEventListener("click",async()=>{await api("/api/admin/logout",{method:"POST"});location.reload()});
check();