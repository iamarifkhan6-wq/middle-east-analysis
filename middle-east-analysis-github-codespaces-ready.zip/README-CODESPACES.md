# Middle East Analysis — GitHub Codespaces

1. Upload this project to a GitHub repository.
2. Open the repository in GitHub and choose **Code → Codespaces → Create codespace on main**.
3. The included `.devcontainer/devcontainer.json` installs dependencies automatically and starts the app on port 3000.
4. If the browser does not open automatically, open the **Ports** panel and click the forwarded port **3000**.
5. Root `/` shows the loading page, then redirects to the homepage.

Admin trial defaults (if no `.env` is provided):
- Email: admin@middleeastanalysis.com
- Password: change-this-password

For anything public, set ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET as Codespaces/Repository secrets or environment variables.
