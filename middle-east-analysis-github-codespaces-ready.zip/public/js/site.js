const header = `
<div class="topbar"><div>Research • Commentary • Perspectives on the Middle East</div><div class="toplinks">X &nbsp; LinkedIn &nbsp; Facebook &nbsp; YouTube &nbsp; ⌕ Search &nbsp; Login</div></div>
<header class="header"><a class="brand" href="/"><span class="brandmark">ME</span><span><b>MIDDLE EAST</b><strong>ANALYSIS</strong><small>RESEARCH • COMMENTARY • PERSPECTIVES</small></span></a><button class="menu-btn" id="menuBtn">☰</button><nav><a href="/">Home</a><a href="/analysis.html">Analysis</a><a href="/commentary.html">Commentary</a><a href="/research.html">Research Articles</a><a href="/student-corner.html">Student Corner</a><a href="/countries.html">Countries</a><a href="/themes.html">Themes</a><a href="/experts.html">Experts</a><a href="/editorial-team.html">About Us</a><a href="/submission.html" class="submit">Submit Your Article</a></nav></header>`;

const footer = `
<footer><div class="footer-grid"><div><div class="footer-brand">MIDDLE EAST<br>ANALYSIS</div><p>Research, analysis and commentary on the Middle East.</p><div class="social">X &nbsp; in &nbsp; f &nbsp; ▶</div></div><div><h4>Quick Links</h4><a href="/">Home</a><a href="/analysis.html">Analysis</a><a href="/commentary.html">Commentary</a><a href="/research.html">Research Articles</a><a href="/student-corner.html">Student Corner</a></div><div><h4>Explore</h4><a href="/countries.html">Countries</a><a href="/themes.html">Themes</a><a href="/experts.html">Experts</a><a href="/editorial-team.html">Editorial Team</a></div><div><h4>Resources</h4><a href="/submission.html">Submission Guidelines</a><a>Editorial Policy</a><a>Privacy Policy</a><a>Terms of Use</a></div><div><h4>Subscribe</h4><p>Get the latest analysis and updates.</p><input placeholder="Your email address"><button>Subscribe</button></div></div><div class="copyright">© 2026 Middle East Analysis. All rights reserved.</div></footer>`;

document.getElementById("site-header")?.insertAdjacentHTML("afterbegin", header);
document.getElementById("site-footer")?.insertAdjacentHTML("afterbegin", footer);

document.getElementById("menuBtn")?.addEventListener("click", () => document.querySelector("nav")?.classList.toggle("open"));

function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function articleCard(a){
 return `<article class="card"><div class="image-placeholder ${a.category.toLowerCase().replace(/[^a-z]+/g,"-")}"></div><span class="tag">${esc(a.category)}</span><h3><a href="/article/${encodeURIComponent(a.slug)}">${esc(a.title)}</a></h3><p>${esc(a.author_name)} · ${new Date(a.published_at||a.created_at).toLocaleDateString()} · ${Math.max(4,Math.round((a.body||"").split(/\s+/).length/180))} min read</p></article>`;
}

async function loadLatest(){
 const box=document.getElementById("latestArticles"); if(!box)return;
 try{const r=await fetch("/api/articles?status=published");const data=await r.json();box.innerHTML=data.length?data.slice(0,8).map(articleCard).join(""):`<p class="muted">No published articles yet.</p>`}
 catch(e){box.innerHTML=`<p class="muted">Unable to load articles.</p>`}
}
loadLatest();

const form=document.getElementById("submissionForm");
form?.addEventListener("submit",async e=>{
 e.preventDefault();const msg=document.getElementById("formMessage");msg.textContent="Sending…";
 try{const r=await fetch("/api/submissions",{method:"POST",body:new FormData(form)});const d=await r.json();if(!r.ok)throw new Error(d.error);msg.textContent=d.message;msg.className="success";form.reset()}catch(err){msg.textContent=err.message;msg.className="error"}
});

async function loadArticle(){
 const page=document.getElementById("articlePage"); if(!page)return;
 const slug=decodeURIComponent(location.pathname.split("/").pop());
 try{const r=await fetch("/api/articles/"+encodeURIComponent(slug));const a=await r.json();if(!r.ok)throw new Error(a.error);
 page.innerHTML=`<small class="eyebrow">${esc(a.category)}</small><h1>${esc(a.title)}</h1><div class="article-meta">By <b>${esc(a.author_name)}</b>${a.institution?" · "+esc(a.institution):""} · ${new Date(a.published_at||a.created_at).toLocaleDateString()}</div>${a.image?`<img class="article-image" src="${a.image}" alt="">`:""}<div class="article-body">${a.body.split(/\n+/).map(x=>`<p>${esc(x)}</p>`).join("")}</div>${a.bio?`<div class="author-box"><b>About the author</b><p>${esc(a.bio)}</p></div>`:""}`;
 }catch(e){page.innerHTML=`<h1>Article not found</h1><p class="muted">${esc(e.message)}</p>`}
}
loadArticle();