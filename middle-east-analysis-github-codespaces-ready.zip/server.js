require("dotenv").config();

const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

const root = __dirname;
const publicDir = path.join(root, "public");
const dataDir = path.join(root, "data");
const uploadDir = path.join(publicDir, "uploads");

fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const db = new Database(path.join(dataDir, "middle-east-analysis.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  author_name TEXT NOT NULL,
  email TEXT NOT NULL,
  institution TEXT,
  contributor_type TEXT,
  category TEXT NOT NULL,
  abstract TEXT,
  body TEXT NOT NULL,
  bio TEXT,
  image TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  editor_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  published_at TEXT
);

CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@middleeastanalysis.com";
const adminPassword = process.env.ADMIN_PASSWORD || "change-this-password";

const existingAdmin = db.prepare("SELECT id FROM admins WHERE email = ?").get(adminEmail);
if (!existingAdmin) {
  db.prepare("INSERT INTO admins (email, password_hash) VALUES (?, ?)")
    .run(adminEmail, bcrypt.hashSync(adminPassword, 12));
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, uploadDir),
    filename: (_, file, cb) => {
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "-");
      cb(null, `${Date.now()}-${safe}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (/^image\\/(jpeg|png|webp)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only JPG, PNG and WebP images are allowed."));
  }
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(publicDir, { index: false }));

app.get("/", (req, res) => {
  res.sendFile(path.join(publicDir, "loading.html"));
});

function slugify(value) {
  return value.toLowerCase().trim()
    .replace(/[^a-z0-9\\s-]/g, "")
    .replace(/\\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 90);
}

function uniqueSlug(title, id = null) {
  let slug = slugify(title) || `article-${Date.now()}`;
  let candidate = slug;
  let i = 2;
  while (true) {
    const row = id
      ? db.prepare("SELECT id FROM articles WHERE slug = ? AND id != ?").get(candidate, id)
      : db.prepare("SELECT id FROM articles WHERE slug = ?").get(candidate);
    if (!row) return candidate;
    candidate = `${slug}-${i++}`;
  }
}

function requireAdmin(req, res, next) {
  if (!req.session.adminId) return res.status(401).json({ error: "Admin login required." });
  next();
}

app.get("/api/articles", (req, res) => {
  const status = req.query.status || "published";
  const rows = db.prepare(`
    SELECT id,title,slug,author_name,institution,contributor_type,category,abstract,bio,image,
           status,editor_note,created_at,published_at
    FROM articles WHERE status = ? ORDER BY COALESCE(published_at, created_at) DESC
  `).all(status);
  res.json(rows);
});

app.get("/api/articles/:slug", (req, res) => {
  const row = db.prepare("SELECT * FROM articles WHERE slug = ?").get(req.params.slug);
  if (!row || (row.status !== "published" && !req.session.adminId))
    return res.status(404).json({ error: "Article not found." });
  res.json(row);
});

app.post("/api/submissions", upload.single("image"), (req, res) => {
  const { name, email, institution, contributorType, title, category, abstract, article, bio } = req.body;

  if (!name || !email || !title || !category || !article) {
    return res.status(400).json({ error: "Name, email, title, category and article are required." });
  }

  const slug = uniqueSlug(title);
  const image = req.file ? `/uploads/${req.file.filename}` : null;

  db.prepare(`
    INSERT INTO articles
    (title,slug,author_name,email,institution,contributor_type,category,abstract,body,bio,image,status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending')
  `).run(
    title.trim(), slug, name.trim(), email.trim(), institution || null,
    contributorType || null, category, abstract || null, article.trim(),
    bio || null, image
  );

  res.json({ ok: true, message: "Submission received and sent to the editorial team for review." });
});

app.post("/api/admin/login", (req, res) => {
  const { email, password } = req.body;
  const admin = db.prepare("SELECT * FROM admins WHERE email = ?").get(email);
  if (!admin || !bcrypt.compareSync(password || "", admin.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }
  req.session.adminId = admin.id;
  res.json({ ok: true });
});

app.post("/api/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/admin/me", requireAdmin, (req, res) => {
  res.json({ ok: true });
});

app.get("/api/admin/submissions", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT id,title,author_name,email,institution,contributor_type,category,abstract,bio,
           status,editor_note,created_at,published_at
    FROM articles ORDER BY created_at DESC
  `).all();
  res.json(rows);
});

app.get("/api/admin/submissions/:id", requireAdmin, (req, res) => {
  const row = db.prepare("SELECT * FROM articles WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Submission not found." });
  res.json(row);
});

app.patch("/api/admin/submissions/:id", requireAdmin, (req, res) => {
  const { status, editorNote, title, category, abstract, body, bio } = req.body;
  const allowed = ["pending", "approved", "rejected"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status." });

  const current = db.prepare("SELECT * FROM articles WHERE id = ?").get(req.params.id);
  if (!current) return res.status(404).json({ error: "Submission not found." });

  const nextTitle = title?.trim() || current.title;
  const nextSlug = nextTitle !== current.title ? uniqueSlug(nextTitle, current.id) : current.slug;
  const publishedAt = status === "approved"
    ? (current.published_at || new Date().toISOString())
    : null;

  db.prepare(`
    UPDATE articles SET
      title=?, slug=?, category=?, abstract=?, body=?, bio=?,
      status=?, editor_note=?, published_at=?
    WHERE id=?
  `).run(
    nextTitle, nextSlug, category || current.category,
    abstract ?? current.abstract, body ?? current.body, bio ?? current.bio,
    status, editorNote ?? current.editor_note, publishedAt, current.id
  );

  res.json({ ok: true });
});

app.delete("/api/admin/submissions/:id", requireAdmin, (req, res) => {
  const row = db.prepare("SELECT image FROM articles WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Submission not found." });

  db.prepare("DELETE FROM articles WHERE id = ?").run(req.params.id);

  if (row.image) {
    const file = path.join(publicDir, row.image.replace(/^\\//, ""));
    if (fs.existsSync(file)) fs.unlinkSync(file);
  }

  res.json({ ok: true });
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(publicDir, "admin.html"));
});

app.get("/article/:slug", (req, res) => {
  res.sendFile(path.join(publicDir, "article.html"));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(400).json({ error: err.message || "Request failed." });
});

app.listen(PORT, () => {
  console.log(`Middle East Analysis running at http://localhost:${PORT}`);
});
