# Splash screen

Open `/` to see the Middle East Analysis splash screen. It uses the Jerusalem background and MEA logo embedded directly into `public/loading.html`, so the splash does not depend on image-path resolution. After 3 seconds it opens `/index.html`, the existing homepage.
